package edu.eci.arsw.moneylaundering;

public class Transaction {
    public int amount;
    public String originAccount;
    public String destinationAccount;
}

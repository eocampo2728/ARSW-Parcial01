package edu.eci.arsw.exams.moneylaunderingapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneylaunderingapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
